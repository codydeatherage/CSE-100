#include <iostream>
#include <string>
#include <vector>
#include <list>
#include "Hash.h"

using namespace std;


/****************************************************************
 * CONSTRUCTOR
 ****************************************************************/
Hash::Hash(int _bNo) {
}

/****************************************************************
 * DESTRUCTOR
 ****************************************************************/
Hash::~Hash() {
  // Write code to remove and deallocate everything
}

void Hash::Insert(int toInsert) {
  // Write your code here
}

bool Hash::Delete(int toDelete) {
  // Write your code here
	return true;
}

bool Hash::Search(int key, int& _bucket, int& _pos) {
  // Write your code here
	return true;
}

void Hash::Print() {
  // Write your code here
}

